This directory contains various scripts and other files useful for 
maintaining a MOO.  They are derived from those that Diversity 
University uses in its own operations.  Certain sub-directory structures 
are assumed, and if yours are different you may have to perform some 
customization of the scripts.  We find our arrangement very convenient, 
though, so you might want to emulate it.  The basic structure is:

/usr/du/bin/			binary files and MOO maintenance scripts
       /home/			home directories for MOO support personnel
       /moo/			the place where the MOO database file is
           /moo			a soft link to server-source/MOO-1.8.0p6/moo
           /du.db		our MOO database file
           /files/		where the FUP-accessible files are
           /backup.dbs/		where backup MOO databases are
           /backup.logs/	where backup server logs are
           /server-source/	where the server source directories are
                         /MOO-1.8.0p6/	the unpacked server source
                         /patches/	server patches

Subdirectories in the above listing are indicated by a "/" at the end.

Scripts and other files are kept in the following places:

chown		in /usr/du/bin
dobackup	in /usr/du/bin
runmoo		in /usr/du/bin
statmoo		in /usr/du/bin
watchmoo	in /usr/du/bin
crontab.moo	in /usr/du/moo
statmoo.cgi	in our httpd cgi-directory (set by httpd srm.conf)

All DU server maintenance personnel have the du/bin directory added to 
their PATH list.  They can issue "runmoo" to start the MOO.  The MOO is 
halted from inside the MOO itself, using the @shutdown command.  Our 
runmoo command is the equivalent to the "restart" script distributed with 
the LambdaMOO server.

The watchmoo script is a simple method of watching the MOO's log 
continuously, which is especially useful when starting or stopping the 
server.

The nightly archiving system, which stores a copy of the MOO database as 
well as a copy of all FUP-based external files, must be started 
separately.  The backup process stores all these as a single tar.gz 
file.  See the crontab.moo file, and change the values to point 
to your MOO database.  Note that this is also where to set how many 
days of backups you want.  For instance, you might want a running 7 day 
backup set, and once a week set aside (by hand) a copy for long-term 
storage.  Once you've customized the dobackup and crontab.moo files 
appropriately, use "crontab crontab.moo" to schedule the backup process.
Note that you must have access to gzip and tar on your system for the 
nightly archiving to function.

Although one person can generally maintain the UNIX side of the MOO 
operation, it is common to have a group of people who do so.  To allow a 
group to all have access to the required files, we suggest the 
following:
    1. Establish a UNIX group to own all MOO-related materials (add a 
line to the /etc/group file).  It might be called "mookeepers" for 
example.  Make sure all maintenance personnel are in the group, either 
by having their name in the /etc/group file entry, or through their 
/etc/passwd file entry.
    2. When you create the /usr/moo directory that will hold all MOO-
related files, make sure it is, a) owned by the mookeepers group, b) 
the sticky-bit for the directory is set.  This will insure that all 
files and sub-directories created under this directory are owned by 
the mookeepers group.  If you already created /usr/moo directory (or 
whatever you called it), change the group ownership of that directory 
and all its contents (you may need your sysop to do this for you)
    3. If  the UNIX accounts for your MOO maintenance staff are ONLY 
used for MOO maintenance, it is convenient to change their default 
"umask" setting such that all files they create will be writable by the 
other maintainers.  To do this, add the line "umask 007" to the 
".login" script in the home directories of your MOO maintenance staff.  
This will insure all the files they create are group-writable, and 
therefore can be edited by other MOO maintenance staff.  Note that if 
they do other work using their account, those files will also be group-
writable unless specifically altered.  If your staff routinely do both 
MOO maintenance and personal work on the UNIX system, you might 
consider making special MOO maintenance accounts for them, which will 
be in the mookeepers group and have a default umask value making files 
created with that account group-writable.  Their personal account would 
neither be in the mookeepers group, nor use the group-writable umask 
value.

The chown script is a convenient tool for allowing a group of 
maintainers to share files at a site where none of them has root 
access.  When setuid root, it allows them to chown files back and 
forth, even if the server generally restricts such chown'ing, by 
limiting such actions to only people within the same group.  For 
instance, all DU maintenance personnel for the DU Main Campus are in 
the "du" UNIX system group.

The statmoo and statmoo.cgi scripts give a snapshot summary of the MOO 
server operations.  The statmoo.cgi is especially useful for determining 
if your MOO is using appropriate amounts of server resources.  You can 
see the DU Main Campus MOO's summary generated by statmoo.cgi at:
    http://www.du.org/statmoo
The statmoo script just provides a quick summary without analysis.  At 
DU's site, the statmoo.cgi file is the one accessed, and has been 
renamed "statmoo" for convenience.  Note that these scripts may not 
function correctly with operating systems other than Solaris, unless 
suitably modified.

Last updated: 13May97

